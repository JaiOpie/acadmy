/**
 * Copyright (c) 2023 LTIM. All rights reserved*/
package com.ltim.joritz.demo.service;

import java.util.Objects;

import org.springframework.data.jpa.domain.Specification;

import com.ltim.platforms.joritz.core.starter.util.LoggingUtil;
import com.ltim.platforms.joritz.core.starter.search.SearchCriteria;
import com.ltim.platforms.joritz.core.starter.search.SearchDto;

import com.ltim.joritz.demo.entity.*;
import com.ltim.joritz.demo.constants.*;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

/**
 * Class implements Specification to override predicate method for creation of criteria builder
 * @author Gurudatta H
 */
public class SampleSpecification implements Specification<SampleEntity> {
	
	private final SearchCriteria searchCriteria;
	
	private final LoggingUtil logger = new LoggingUtil(this.getClass());
	
	/**
	 * Constructs a new SampleSpecification with the specified search criteria.
	 * @param searchCriteria criteria for searching and filtering the data
	 */
	public SampleSpecification(final SearchCriteria searchCriteria)
	{
		super();
		this.searchCriteria = searchCriteria;
	}
	
	/**
	 *performs the creation of criteria builder to form a query  
	 *@param root the entity on which the query is created
	 *@param query parameter
	 *@param cb the criteria builder to create query based on search filter criteria
	 */
	@Override
	public Predicate toPredicate(Root<SampleEntity> root, CriteriaQuery<?> query, CriteriaBuilder cb) 
	{
		String strToSearch = null;
		if(searchCriteria.getValue() !=null)
		{
			strToSearch = searchCriteria.getValue().toString().toLowerCase();
		}
		
		switch(Objects.requireNonNull(SearchOperation.getSimpleOperation(searchCriteria.getOperation())))
		{
			case CONTAINS:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.like(cb.lower(root.get(searchCriteria.getFilterKey())),"%" + strToSearch + "%");
				}
				else
				{
					logger.info("given key cannot be filtered in"," CONTAINS criteria::");
				}
			   
			
			case DOES_NOT_CONTAIN:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.notLike(cb.lower(root.get(searchCriteria.getFilterKey())),"%" + strToSearch + "%");
				}
				else
				{
					logger.info("given key cannot be filtered in"," DOES_NOT_CONTAIN criteria::");
				}
				
			case EQUAL:
				return cb.equal(root.get(searchCriteria.getFilterKey()), strToSearch );

			case NOT_EQUAL:
				return cb.notEqual(root.get(searchCriteria.getFilterKey()),strToSearch);
				
			case BEGINS_WITH:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.like(cb.lower(root.get(searchCriteria.getFilterKey())),strToSearch + "%");
				}
				else
				{
					logger.info("given key cannot be filtered in"," BEGINS_WITH criteria::");
				}
				
			case DOES_NOT_BEGIN_WITH:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.notLike(cb.lower(root.get(searchCriteria.getFilterKey())),strToSearch + "%");
				}
				else
				{
					logger.info("given key cannot be filtered in"," DOES_NOT_BEGIN_WITH criteria::");
				}
				
			case ENDS_WITH:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.like(cb.lower(root.get(searchCriteria.getFilterKey())),"%" + strToSearch);
				}
				else
				{
					logger.info("given key cannot be filtered in"," ENDS_WITH criteria::");
				}
				
			case DOES_NOT_END_WITH:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.notLike(cb.lower(root.get(searchCriteria.getFilterKey())),"%" + strToSearch );
				}
				else
				{
					logger.info("given key cannot be filtered in ","DOES_NOT_END_WITH criteria::");
				}
				
			case NUL:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.isNull(root.get(searchCriteria.getFilterKey()));
				}
				else
				{
					logger.info("given key cannot be filtered in"," NULL criteria::");
				}
				
			case NOT_NULL:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_NAME) || searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_DESCRIPTION) || searchCriteria.getFilterKey().equals(SampleConstants.CREATED_BY))
				{
					return cb.isNotNull(root.get(searchCriteria.getFilterKey()));
				}
				else
				{
					logger.info("given key cannot be filtered in"," NOT_NULL criteria::");
				}
				
			case GREATER_THAN:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_ID))
				{
					return cb.gt(root.get(searchCriteria.getFilterKey()),Long.parseLong(strToSearch));
				}
				else
				{
					logger.info("given key cannot be filtered in"," GREATER_THAN criteria::");
				}
				
			case GREATER_THAN_EQUAL:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_ID))
				{
					return cb.ge(root.get(searchCriteria.getFilterKey()),Long.parseLong(strToSearch));
				}
				else
				{
					logger.info("given key cannot be filtered in"," GREATER_THAN_EQUAL criteria::");
				}
				
			case LESS_THAN:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_ID))
				{
					return cb.lt(root.get(searchCriteria.getFilterKey()),Long.parseLong(strToSearch));
				}
				else
				{
					logger.info("given key cannot be filtered in ","LESS_THAN criteria::");
				}
				
			case LESS_THAN_EQUAL:
				if(searchCriteria.getFilterKey().equals(SampleConstants.SAMPLE_ID))
				{
					return cb.le(root.get(searchCriteria.getFilterKey()),Long.parseLong(strToSearch));
				}
				else
				{
					logger.info("given key cannot be filtered in ","LESS_THAN_EQUAL criteria::");
				}
				
			default:
				return null;
		}
	}
}