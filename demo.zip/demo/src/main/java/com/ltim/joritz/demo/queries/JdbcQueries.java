package com.ltim.joritz.demo.queries;

/**Copyright (c) 2023 LTIM. All rights reserved
@author Prakhar Gupta
@summary class contains the constant JDBC queries */

public class JdbcQueries {

	public static final String GET_ALL_SAMPLE = "SELECT * FROM SampleEntity";
	public static final String GET_SAMPLE_BY_STATUS= "SELECT * FROM SampleEntity WHERE STATUS=:status";
	
}
