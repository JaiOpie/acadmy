
/**Copyright (c) 2023 LTIM. All rights reserved*/
package com.ltim.joritz.demo.controller;
import java.util.Map;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.context.MessageSource;

import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Arrays;
import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;

import com.ltim.joritz.demo.service.SampleService;
import com.ltim.joritz.demo.service.SampleSpecificationBuilder;

import com.ltim.joritz.demo.entity.*;
import com.ltim.joritz.demo.constants.*;
import com.ltim.platforms.joritz.core.starter.search.SearchCriteria;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;

import com.ltim.platforms.joritz.core.starter.search.SearchDto;
import com.ltim.platforms.joritz.core.starter.constants.JoritzCoreConstants;
import com.ltim.platforms.joritz.core.starter.exception.UserValidationException;
import com.ltim.platforms.joritz.core.starter.exception.ValidationException;
import com.ltim.platforms.joritz.core.starter.util.ApiResponse;
import com.ltim.platforms.joritz.core.starter.util.LoggingUtil;
import com.ltim.platforms.joritz.auth.starter.util.PermissionUtil;
import com.ltim.platforms.joritz.core.starter.util.ResponseSettingUtil;
import com.ltim.platforms.joritz.core.starter.util.StandardEndPointsUtil;
import com.ltim.platforms.joritz.core.starter.util.ValidationUtil;

/**
* Sample Controller  class contains the rest end points.
*  
* @author Archana reddy
*/
@RestController
public class SampleController {

	@Autowired
	SampleService sampleService;

	@Autowired
	MessageSource ms;

	@Autowired
	ResponseSettingUtil responseSettingUtil;

	@Autowired
	StandardEndPointsUtil standardEndPointsUtil;

	@Autowired
	private ValidationUtil validatorUtil;

	@Autowired
	private PermissionUtil permissionUtil;

	private final LoggingUtil logger = new LoggingUtil(this.getClass());


	/**
	    * Add a Sample Entity to a specific group within a tenant using a POST request.
	    * ex- api/service/{groupId}/samples
	    * @param groupId The unique identifier of the group to which the Sample Entity should be added.
	    * @param sampleEntity The Sample Entity to be added.
	    * @return A ResponseEntity<ApiResponse> response indicating the result of the operation.
	    * @throws UserValidationException If the user does not have the necessary permission to manage Sample Entities.
	    * @throws MethodArgumentNotValidException if the input is invalid
	    * @throws Exception throws the generic exception
	    */
	
	@PostMapping("#{standardEndPointsUtil.getAddEntityEndPointPath('samples')}")
	public ResponseEntity<ApiResponse> addSample(@Valid @RequestHeader(name = JoritzCoreConstants.TENANT_ID_HEADER) long tenantId,
			@PathVariable long groupId, @RequestBody SampleEntity sampleEntity) 
					throws  MethodArgumentNotValidException {
		
		try {
			// validate permission
			logger.info("addSample", "check manage permission......");
			if (permissionUtil.hasClientScope(tenantId,PermissionScope.MANAGE_ACCESS, getCurrentUserId() )) {
				// validate inputs
				
				sampleEntity.setCreatedBy(getCurrentUserId());
				
				SampleEntity sampleAdded = sampleService.addSampleEntity(sampleEntity);
				return responseSettingUtil.setSuccessResponse(sampleAdded, 
						JoritzCoreConstants.API_ADD_ENTITY_SUCCESS_MESSAGE);

			} else {
				throw new UserValidationException(SampleConstants.NO_MANAGE_PERMISSION);
			}
		} catch (UserValidationException e) {
			return responseSettingUtil. setErrorResponse(e.getMessage());

		} catch (Exception e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());
		}
	}

	/**
	    * To update the sample entity  to a specific group within a tenant using a PUT request.
	    * ex- api/service/{groupId}/samples/{entityId}
	    * @param groupId The unique identifier of the group to which the Sample Entity should be updated.
	    * @param entityId The entityId for updating the particular record.
	    * @param sampleEntity it is sample Entity which needs to be updated.
	    * @return A ResponseEntity<ApiResponse> response indicating the result of the operation.
	    * @throws UserValidationException If the user does not have the necessary permission to manage Sample Entities.
	    * @throws MethodArgumentNotValidException if the input feild is invalid
	    * @throws ValidationException if the input parameter is invalid.
	    * @throws Exception throws the generic exception.
	    */
	@PutMapping("#{standardEndPointsUtil.getUpdateEntityEndPointPath('samples')}")
	public ResponseEntity<ApiResponse> updateSample(@Valid @RequestHeader(name = JoritzCoreConstants.TENANT_ID_HEADER) long tenantId,
			@PathVariable long groupId,  @PathVariable long entityId, @RequestBody SampleEntity sampleEntity) 
					throws  MethodArgumentNotValidException {
		try {
			// validate inputs
			if (entityId > 0) {
				// validate permission
				if (permissionUtil.hasResourceScope(tenantId, String.valueOf(entityId), PermissionScope.MANAGE_ACCESS,getCurrentUserId())) {
					
					SampleEntity sampleEntityUpdated = sampleService.getSampleEntityById(entityId);
					
					sampleEntityUpdated.setModifiedBy(getCurrentUserId());
					sampleEntityUpdated.setSampleDescription(sampleEntity.getSampleDescription());
					sampleEntityUpdated.setSampleName(sampleEntity.getSampleName());
					
					sampleEntityUpdated = sampleService.updateSampleEntity(sampleEntityUpdated);
					
					return responseSettingUtil.setSuccessResponse(sampleEntityUpdated,
							JoritzCoreConstants.API_UPDATE_ENTITY_SUCCESS_MESSAGE);
				} else {
					throw new UserValidationException(SampleConstants.NO_MANAGE_PERMISSION);
				}
			} else {
				throw new ValidationException(SampleConstants.INVALID_ENTITY_ID);
			}
			
		} catch (ValidationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());

		} catch (UserValidationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());

		} catch (ConstraintViolationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage()); 
			
		}  catch (Exception e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());
		}
	}

	/**
    * To get the sample entites  to a specific group within a tenant using a GET request.
    * ex- api/service/{groupId}/samples
    * @param groupId The unique identifier of the group to fetch all the Samples
    * @param pageNumber it represents the page number , default is 0
    * @param size it is the size per page , default is 5
    * @param sortBy it represents the order in which records needs to be sorted
    * @param orderBy it represents the orderBy asc or desc
    * @return A ResponseEntity<ApiResponse> response indicating the result of the operation.
    * @throws UserValidationException If the user does not have the necessary permission to manage Sample Entities.
    * @throws ValidationException if the input parameter is invalid.
    * @throws Exception throws the generic exception.
    */
	@GetMapping("#{standardEndPointsUtil.getEntitiesEndPointPath('samples')}")
	public ResponseEntity<ApiResponse> getAllSamples(@RequestHeader(name = JoritzCoreConstants.TENANT_ID_HEADER) long tenantId,
			@PathVariable long groupId,
			@RequestParam(defaultValue = JoritzCoreConstants.DEFAULT_PAGE_NUMBER, value = JoritzCoreConstants.PAGE, required = false) int page,
			@RequestParam(defaultValue = JoritzCoreConstants.DEFAULT_SIZE, value = JoritzCoreConstants.SIZE, required = false) int size,
			@RequestParam(defaultValue = SampleConstants.DEFAULT_SORT, value = SampleConstants.SORT_BY_VALUES, required = false) String sortByValues){
		
		logger.info("getAllSamples", "inside getSample controller:");
		
		try {
			// validate permission
			if (permissionUtil.hasClientScope(tenantId,PermissionScope.VIEW,getCurrentUserId())) {
				// validate inputs
				logger.info("getAllSamples", "user is validated:");
					
				List<String> sortByList =  Arrays.asList(sortByValues.split(","));
	             Sort sort;
	             List<Order> orders = new ArrayList<>();

	             for (int i = 0; i < sortByList.size(); i++) 
	             {
	            	 logger.info("searchExecutionServers", sortByList.get(i)); 
	            	 if(sortByList.get(i).toString().split(":")[1].equalsIgnoreCase("ASC"))
	            	 {
	            		 Order order = new Order(Sort.Direction.ASC, sortByList.get(i).toString().split(":")[0]);
	    	             orders.add(order);
	            	 }
	            	 else if(sortByList.get(i).toString().split(":")[1].equalsIgnoreCase("DESC"))
	            	 {
	            		 Order order = new Order(Sort.Direction.DESC, sortByList.get(i).toString().split(":")[0]);
	    	             orders.add(order);
	            	 
	            	 }
	            	 else
	            	 {
	            		 logger.info("searchExecutionServers", "invalid order parameter");
	            	 }
	             }
	             
	             sort = Sort.by(orders);
				
				List<SampleEntity> sampleList = sampleService.getAllSampleEntities(page, size, sort);
				return responseSettingUtil.setSuccessResponse(sampleList, 
						JoritzCoreConstants.API_FETCH_SUCCESS_MESSAGE);

			} else {
				throw new UserValidationException(SampleConstants.NO_MANAGE_PERMISSION);
			}
		} catch (UserValidationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());

		} catch (Exception e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());
		}
	}
	/**
	    * To get the sample entity  to a specific group within a tenant using a GET request.
	    * ex- api/service/{groupId}/samples
	    * @param groupId The unique identifier of the group to fetch the sample entity.
	    * @param entityId The entityId for getting the particular record.
	    * @return A ResponseEntity<ApiResponse> response indicating the result of the operation.
	    * @throws UserValidationException If the user does not have the necessary permission to manage Sample Entities.
	    * @throws ValidationException if the input parameter is invalid.
	    * @throws Exception throws the generic exception.
	    */
	@GetMapping(value="#{standardEndPointsUtil.getEntityEndPointPath('samples')}")
	public ResponseEntity<ApiResponse> getSample(@RequestHeader(name = JoritzCoreConstants.TENANT_ID_HEADER) long tenantId,
			@PathVariable long groupId, 
			@PathVariable long entityId)  {
		try {
			// validate permission
			if (permissionUtil.hasClientScope(tenantId,PermissionScope.VIEW,getCurrentUserId())) {
				// validate inputs
				if (entityId > 0) {
					SampleEntity sampleEntityUpdated = sampleService.getSampleEntityById(entityId);
					
					return responseSettingUtil.setSuccessResponse(sampleEntityUpdated, 
							JoritzCoreConstants.API_FETCH_SUCCESS_MESSAGE);
					
					
				} else {
					throw new ValidationException(SampleConstants.INVALID_ENTITY_ID);
				}

			} else {
				throw new UserValidationException(SampleConstants.NO_MANAGE_PERMISSION);
			}
		} catch (ValidationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());

		} catch (UserValidationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());

		} catch (Exception e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());
		}
		
	}

	
	/**
    * To update the sample entity with the specific feild  to a specific group within a tenant using a PATCH request.
    * ex- api/service/{groupId}/samples/{entityId}
    * @param groupId The unique identifier of the group to which the Sample Entity should be added.
    * @param entityId The entityId for updating the particular record.
    * @param  payload sample with specific feild.
    * @return A ResponseEntity<ApiResponse> response indicating the result of the operation.
    * @throws UserValidationException If the user does not have the necessary permission to manage Sample Entities.
    * @throws MethodArgumentNotValidException if the input feild is invalid
    * @throws ValidationException if the input parameter is invalid.
    * @throws Exception throws the generic exception.
    */
	@PatchMapping("#{standardEndPointsUtil.getUpdateEntityEndPointPath('samples')}")
	public ResponseEntity<ApiResponse> updateSampleName(@Valid 
			@RequestHeader(name = JoritzCoreConstants.TENANT_ID_HEADER) long tenantId,
			@PathVariable long groupId, @PathVariable long entityId, 
			@RequestBody Map<String, Object> payload) throws  MethodArgumentNotValidException {
		
		try {
			if (entityId > 0) {
				
				if (permissionUtil.hasResourceScope(tenantId, String.valueOf(entityId), 
						PermissionScope.MANAGE_ACCESS,getCurrentUserId())) {
					
					SampleEntity sampleEntityUpdated = sampleService.getSampleEntityById(entityId);
					if (payload.containsKey("sampleName")) {
						
						sampleEntityUpdated.setModifiedBy(getCurrentUserId());
						
						sampleEntityUpdated.setSampleName(payload.get("sampleName").toString());
						sampleService.updateSampleEntity(sampleEntityUpdated);
						
						return responseSettingUtil.setSuccessResponse(sampleEntityUpdated,
							JoritzCoreConstants.API_UPDATE_ENTITY_SUCCESS_MESSAGE);
					} else {
						return responseSettingUtil.setErrorResponse(JoritzCoreConstants.API_UPDATE_FAIL_MESSAGE);
					}
				} else {
					throw new UserValidationException(SampleConstants.NO_MANAGE_PERMISSION);
				}
			} else {
				throw new ValidationException(SampleConstants.INVALID_ENTITY_ID);
			}
		} catch (ValidationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());
		} catch (UserValidationException e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());
		} catch (Exception e) {
			return responseSettingUtil.setErrorResponse(e.getMessage());
		}
	}
	
	/**
	    * get the sample entity with the specific name to a specific group within a tenant using a GET request.
	    *
	    * @param groupId The unique identifier of the group to fetch the sampleEntity.
	    * @param sampleName to get the sample by name
	    * @return A ResponseEntity<ApiResponse> response indicating the result of the operation.
	    * @throws UserValidationException If the user does not have the necessary permission to manage Sample Entities.
	    * @throws Exception throws the generic exception.
	    */
	 @GetMapping("#{standardEndPointsUtil.getEntitiesWithParametersEndPointPath('samples','/name/{sampleName}')}")
	 public ResponseEntity<ApiResponse> getSampleWithSampleName(
			 @RequestHeader(name = JoritzCoreConstants.TENANT_ID_HEADER) long tenantId,
			 @PathVariable long groupId, @PathVariable String sampleName) {
	     try {
	         //validate permission
	         if(permissionUtil.hasClientScope(tenantId,PermissionScope.VIEW,getCurrentUserId())) {
	        	 	byte[] decodedSampleName = Base64.getDecoder().decode(sampleName);
					String sName = new String(decodedSampleName);
	                SampleEntity sample  = sampleService.findSampleEntityByName(sName) ;
	                return responseSettingUtil.setSuccessResponse(sample,JoritzCoreConstants.SUCCESS);                
	         } else {
	             throw new UserValidationException(SampleConstants.NO_MANAGE_PERMISSION);
	         }
	     }  catch (UserValidationException e) {
	         return responseSettingUtil.setErrorResponse(e.getMessage());
	
	     } catch (Exception e) {
	         return responseSettingUtil.setErrorResponse(e.getMessage());
	     }
	 }
	 
	 
	 /**
	    * Search sample entites  to a specific group within a tenant using a GET request.
	    * ex- api/service/{groupId}/samples/search
	    * @param groupId The unique identifier of the group to fetch all the Samples
	    * @param pageNumber it represents the page number
	    * @param size it is the size per page
	    * @param sortBy it represents the order in which records needs to be sorted
	    * @param orderBy it represents the orderBy asc or desc
	    * @return A ResponseEntity<ApiResponse> response indicating the result of the operation.
	    * @throws UserValidationException If the user does not have the necessary permission to manage Sample Entities.
	    * @throws ValidationException if the input parameter is invalid.
	    * @throws Exception throws the generic exception.
	    */
	
	 @PostMapping("#{standardEndPointsUtil.getEntitiesEndPointPath('samples')}/search")
	 public ResponseEntity<ApiResponse> searchSamples( 
			 @RequestHeader(name = JoritzCoreConstants.TENANT_ID_HEADER) long tenantId,
			 @PathVariable long groupId,
			 @RequestParam(defaultValue = JoritzCoreConstants.DEFAULT_PAGE_NUMBER, value = JoritzCoreConstants.PAGE, required = false) int page,
			 @RequestParam(defaultValue = JoritzCoreConstants.DEFAULT_SIZE, value = JoritzCoreConstants.SIZE, required = false) int size,
			 @RequestParam(defaultValue = SampleConstants.DEFAULT_SORT, value = SampleConstants.SORT_BY_VALUES, required = false) String sortByValues,
			 @RequestBody SearchDto searchDto) {
		 
		 try {
	         //validate permission
	         if(permissionUtil.hasClientScope(tenantId,PermissionScope.VIEW,getCurrentUserId())) {
	        	 
	        	 SampleSpecificationBuilder builder = new SampleSpecificationBuilder();
	             List<SearchCriteria> criteriaList = searchDto.getSearchCriteriaList();
	             if(criteriaList != null){
	                 criteriaList.forEach(x-> {
	                	 x.setDataOption(searchDto.getDataOption());
	                	 builder.with(x);
	                 });
	             }
	             
	             List<String> sortByList =  Arrays.asList(sortByValues.split(","));
	             Sort sort;
	             List<Order> orders = new ArrayList<>();

	             for (int i = 0; i < sortByList.size(); i++) 
	             {
	            	 logger.info("searchExecutionServers", sortByList.get(i)); 
	            	 if(sortByList.get(i).toString().split(":")[1].equalsIgnoreCase("ASC"))
	            	 {
	            		 Order order = new Order(Sort.Direction.ASC, sortByList.get(i).toString().split(":")[0]);
	    	             orders.add(order);
	            	 }
	            	 else if(sortByList.get(i).toString().split(":")[1].equalsIgnoreCase("DESC"))
	            	 {
	            		 Order order = new Order(Sort.Direction.DESC, sortByList.get(i).toString().split(":")[0]);
	    	             orders.add(order);
	            	 }
	            	 else
	            	 {
	            		 logger.info("searchExecutionServers", "invalid order parameter");
	            	 }
	             }
	             
	             sort = Sort.by(orders);
	             
	             Pageable pageable = PageRequest.of(page, size, sort);
	             
	             Page<SampleEntity> sampleList = sampleService.findBySearchCriteria(builder.build(),pageable);

	             return responseSettingUtil.setSuccessResponse(sampleList, JoritzCoreConstants.API_FETCH_SUCCESS_MESSAGE);
	             
	         } else {
	             throw new UserValidationException(SampleConstants.NO_MANAGE_PERMISSION);
	         }
	     }  catch (UserValidationException e) {
	         return responseSettingUtil.setErrorResponse(e.getMessage());
	
	     } catch (Exception e) {
	         return responseSettingUtil.setErrorResponse(e.getMessage());
	     }
		 
	 }
	 
	 
	 private String getCurrentUserId() {
	 	return "user1";
	 }
}