
/**Copyright (c) 2023 LTIM. All rights reserved*/
package com.ltim.joritz.demo.repository;

import java.util.List;

import com.ltim.joritz.demo.entity.SampleEntity;


/**
* Jdbc Repo contains  the abstract methods
*  
* @author Archana reddy
*/
public interface JdbcRepo {
	
	/**
	    * @return List of SampleEntities indicating the result of the operation.
	    */
	public abstract  List<SampleEntity> getAllSamples();
}
