/**
 * Copyright (c) 2023 LTIM. All rights reserved*/



package com.ltim.joritz.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import com.ltim.joritz.demo.entity.SampleEntity;


/**
* Sample Service  class contains the abstract methods 
*  
* @author Archana reddy
*/
public interface SampleService {
	
	
	
	/**
	    * @param page it represent the page number.
	    * @param size it represent the size per page
	    * @param it represent the sort order.
	    * @return List of SampleEntites indicating the result of the operation.
	    */
	public abstract List<SampleEntity> getAllSampleEntities(int page, int size, Sort sort);
	/**
	    * @param sampleEntity it represent the sampleEntity.
	    * @return A SampleEntity indicating the result of the operation.
	    */
	public SampleEntity addSampleEntity(SampleEntity sampleEntity);

	/**
	    * @param pageable it represents the pageable object.
	    * @return List of sample entites 
	    */
	public List<SampleEntity> findSampleEntities(Pageable pageable);

	/**
	    * @param sample it represent the sampleEntity.
	    * @return A SampleEntity indicating the result of the operation.
	    */
	public SampleEntity updateSampleEntity(SampleEntity sample);
	
	/**
	    * @param sampleId it represent the sampleId of the sampleEntity.
	    * @return A SampleEntity indicating the result of the operation.
	    */
	public abstract SampleEntity getSampleEntityById(long sampleId);
	
	/**
	    * @param  sampleName it represent the sampleName of the sampleEntity.
	    * @return A SampleEntity indicating the result of the operation.
	    */
	public abstract SampleEntity findSampleEntityByName(String sampleName);
	
	/**
     * returns pages of filtered sample entities
     * @param spec contains filter specifications and data options
     * @param page contains page number and records per page details
     * @return returns pages of filtered sample entity
     */
    public Page<SampleEntity> findBySearchCriteria(Specification<SampleEntity> spec,Pageable page);

}
