/**Copyright (c) 2023 LTIM. All rights reserved */

package com.ltim.joritz.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
* SampleApplication class contains main method, it is the start point of application.
*  
* @author Archana reddy
*/
@SpringBootApplication
@ComponentScan(basePackages = { "com.ltim.platforms.joritz.core.starter","com.ltim.platforms.joritz.auth.starter","com.ltim.platforms.joritz.database.starter","com.ltim.joritz.demo"})
public class SampleApplication {
	
	
    /**
     * A main method to start this application.
     * @throws Exception 
     */
	
    public static void main(String Args[]) throws Exception {
    	
    	
        SpringApplication.run(SampleApplication.class, Args);
        
	}

}
