package com.ltim.joritz.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ltim.joritz.demo.entity.SampleEntity;



/**Copyright (c) 2023 LTIM. All rights reserved
@author 	Prakhar Gupta
@summary class contains the methods to map the result set.
*/

public class SampleMapper implements RowMapper<SampleEntity> {


	/**
	 * 	 @param rs it represent the result set
	 * 	 @param rowNum it represent the row number
	    * @return List of SampleEntities indicating the result of the operation.
	    */
	public SampleEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
		SampleEntity sample=new SampleEntity();
		sample.setSampleId(rs.getInt("sample_Id"));
		sample.setSampleName(rs.getString("sample_name"));
		sample.setSampleDescription(rs.getString("sample_description"));
		sample.setCreatedBy(rs.getString("created_by"));
		sample.setCreatedOn(rs.getDate("created_on"));
		return sample;
	}

}