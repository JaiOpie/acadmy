/**Copyright (c) 2023 LTIM. All rights reserved*/
package com.ltim.joritz.demo.repository;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ltim.joritz.demo.entity.SampleEntity;
import com.ltim.joritz.demo.mapper.SampleMapper;
import com.ltim.joritz.demo.queries.JdbcQueries;



/**
* SampleRepositoryImpl class implements the jdbc repo.
*  
* @author Archana reddy
*/

@Repository
public class SampleRepositoryImpl  implements JdbcRepo{

	private final NamedParameterJdbcTemplate jdbcTemplate;
	
	
	@Autowired
	public SampleRepositoryImpl(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate=jdbcTemplate;
	}

	
	/**
	    * @return List of SampleEntities indicating the result of the operation.
	    */
	public List<SampleEntity> getAllSamples() {
		return jdbcTemplate.query(JdbcQueries.GET_ALL_SAMPLE,new SampleMapper()); 
	}

}
