/**Copyright (c) 2023 LTIM. All rights reserved*/


package com.ltim.joritz.demo.config;


import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/**
* Internationalization class to set the languages.
*  
* @author Archana reddy
*/

@Configuration
public class Internationalization implements WebMvcConfigurer{

	@Bean
	public LocaleResolver localeResolver(){
        AcceptHeaderLocaleResolver localeResolver = new AcceptHeaderLocaleResolver();
        localeResolver.setDefaultLocale(Locale.US);
        return  localeResolver;
    }
}
