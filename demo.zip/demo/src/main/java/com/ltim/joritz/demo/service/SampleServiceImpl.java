/**
 * Copyright (c) 2023 LTIM. All rights reserved*/
package com.ltim.joritz.demo.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.ltim.joritz.demo.entity.SampleEntity;
import com.ltim.joritz.demo.repository.SampleRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.PageRequest;
import com.ltim.platforms.joritz.core.starter.util.LoggingUtil;

/**
* SampleService Impl class contains the implementation of the service class
*  
* @author Archana reddy
*/
@Service
public class SampleServiceImpl implements SampleService {

	private final LoggingUtil logger = new LoggingUtil(this.getClass());

	@Autowired
	SampleRepository sampleRepository;


	/**
    * @param page it represent the page number
    * @param size it represent the page size
    * @param sort it represent the sort order 
    * @return A SampleEntity indicating the result of the operation.
    */
	public List<SampleEntity> getAllSampleEntities(int page, int size, Sort sort) {

		logger.info("getAllSamples", "Samples fetch successfully");
		Pageable pageable = PageRequest.of(page, size, sort);
		List<SampleEntity> sampleList = sampleRepository.findAll(pageable).getContent();
		return sampleList;
	}


	/**
    * @param sampleEntity The Sample Entity to be added.
    * @return A SampleEntity indicating the result of the operation.
    */
	public SampleEntity addSampleEntity(SampleEntity sampleEntity) {
		sampleEntity.setCreatedOn(new Date());
		return sampleRepository.save(sampleEntity);
	}

	/**
    * @param pageable 
    * @return List of sample Entities.
    */
	public List<SampleEntity> findSampleEntities(Pageable pageable) {

		return sampleRepository.findAll(pageable).getContent();
	}


	/**
    * @param sample it represent the sampleName of the sampleEntity
    * @return A SampleEntity indicating the result of the operation.
    */
	public SampleEntity updateSampleEntity(SampleEntity sample) {
		sample.setModifiedOn(new Date());
		SampleEntity sampleUpdate = sampleRepository.save(sample);
		return sampleUpdate;
	}

	/**
    * @param sampleId it represent the sampleId of the sampleEntity
    * @return A SampleEntity indicating the result of the operation.
    */
	public SampleEntity getSampleEntityById(long sampleId) {
		return sampleRepository.findById(sampleId).get(); 
	}
	
	/**
    * @param sampleName it represent the name of the sampleEntity.
    * @return A SampleEntity indicating the result of the operation.
    */
	public SampleEntity findSampleEntityByName(String sampleName) {

		return sampleRepository.findBySampleName(sampleName);

	}
	
	/**
     * returns pages of filtered sample entities
     * @param spec contains filter specifications and data options
     * @param page contains page number and records per page details
     * @return returns pages of filtered sample entity
     */
    public Page<SampleEntity> findBySearchCriteria(Specification<SampleEntity> spec, Pageable page) {
            return sampleRepository.findAll(spec, page);
    }
    
}
