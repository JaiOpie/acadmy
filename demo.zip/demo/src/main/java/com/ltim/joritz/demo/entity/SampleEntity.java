
/**Copyright (c) 2023 LTIM. All rights reserved*/


package com.ltim.joritz.demo.entity;
import java.util.Date;

import com.ltim.joritz.demo.constants.SampleConstants;
import com.ltim.platforms.joritz.core.starter.constants.JoritzCoreConstants;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
* Sample Entity class contains the enitity feilds , getter and setters.
*  
* @author Archana reddy
*/
@Table(name = "SampleEntity")
@Entity
public class SampleEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long sampleId;
	
	@NotEmpty(message = SampleConstants.NAME_NOT_EMPTY)
	@Pattern(regexp = SampleConstants.NAME_REGEX_PATTERN, message = SampleConstants.NAME_ALLOWED_CHARACTERS) // used
	@Size(min = SampleConstants.NAME_MIN_VALUE, max = SampleConstants.NAME_MAX_VALUE, message = SampleConstants.NAME_SIZE_RANGE)
	private String sampleName;
	
	@Size(min = SampleConstants.DESCRIPTION_MIN_VALUE, max = SampleConstants.DESCRIPTION_MAX_VALUE, message = SampleConstants.NAME_SIZE_RANGE)
	@Column(name = SampleConstants.SAMPLE_DESCRIPTION)
	private String sampleDescription;
	
	@Column(name = SampleConstants.CREATED_ON)
	private Date createdOn;
	
	@Column(name = SampleConstants.CREATED_BY)
	private String createdBy;
	
	
	@Column(name = SampleConstants.MODIFIED_BY)
	private String modifiedBy;
	
	@Column(name = SampleConstants.MODIFIED_ON)
	private Date modifiedOn;
	
	public SampleEntity() {
		
	}

	public SampleEntity(long sampleId, String sampleName, String sampleDescription) {
		this.sampleId=sampleId;
		this.sampleName=sampleName;
		this.sampleDescription=sampleDescription;
	}
	
	
	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public long getSampleId() {
		return sampleId;
	}

	public void setSampleId(long sampleId) {
		this.sampleId = sampleId;
	}

	public String getSampleName() {
		return sampleName;
	}

	public void setSampleName(String sampleName) {
		this.sampleName = sampleName;
	}

	public String getSampleDescription() {
		return sampleDescription;
	}

	public void setSampleDescription(String sampleDescription) {
		this.sampleDescription = sampleDescription;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "SampleEntity [sampleId=" + sampleId + ", sampleName=" + sampleName + ", sampleDescription="
				+ sampleDescription + ", createdOn=" + createdOn + ", createdBy=" + createdBy + ", modifiedBy="
				+ modifiedBy + ", modifiedOn=" + modifiedOn + "]";
	}
}
