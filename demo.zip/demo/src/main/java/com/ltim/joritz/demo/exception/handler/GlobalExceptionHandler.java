package com.ltim.joritz.demo.exception.handler;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.ltim.platforms.joritz.core.starter.util.ApiResponse;
import com.ltim.platforms.joritz.core.starter.util.ResponseSettingUtil;
import com.ltim.platforms.joritz.database.starter.exception.TenantResolverException;

/**
 * Copyright (c) 2023 LTIM. All rights reserved
 * 
 * @author Prakhar Gupta 
  @summary class contains exception
 */

@ControllerAdvice
public class GlobalExceptionHandler {

	@Autowired
	ResponseSettingUtil responseData;

	/**
    * @param it represent the exception
    * @return A SampleEntity indicating the result of the operation.
    */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ApiResponse>  handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		List<String> details = new ArrayList<String>();
		for (ObjectError error : ex.getBindingResult().getAllErrors()) {
			details.add(error.getDefaultMessage());
		}
		return responseData.setErrorResponse(String.valueOf(details));
	}
	
	
	
}
