/**
 * Copyright (c) 2023 LTIM. All rights reserved*/


package com.ltim.joritz.demo.repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import com.ltim.joritz.demo.entity.SampleEntity;

/**
* SampleRepository class contains the abstract methods to perform the operations in the db
*  
* @author Archana reddy
*/
@Repository
public interface SampleRepository extends JpaRepository<SampleEntity, Long>, JpaSpecificationExecutor<SampleEntity> {
	

	/**
	    * @param sampleName it represent the sampleName
	    * @return A SampleEntity indicating the result of the operation.
	    */
	public abstract SampleEntity findBySampleName(String sampleName);

}