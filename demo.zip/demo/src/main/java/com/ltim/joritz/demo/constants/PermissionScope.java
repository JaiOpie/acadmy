/**Copyright (c) 2023 LTIM. All rights reserved*/
package com.ltim.joritz.demo.constants;

/**
* Permission Scope class contains the permission constants.
*  
* @author Archana reddy
*/

public class PermissionScope {
	
	public static String VIEW = "view";
	public static final String MANAGE_ACCESS = "manage-access";
		
}