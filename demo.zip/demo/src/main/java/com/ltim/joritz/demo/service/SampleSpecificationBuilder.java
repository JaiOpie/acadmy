/**
 * Copyright (c) 2023 LTIM. All rights reserved*/
package com.ltim.joritz.demo.service;

import com.ltim.joritz.demo.entity.*;
import com.ltim.joritz.demo.constants.*;

import com.ltim.platforms.joritz.core.starter.search.SearchCriteria;
import com.ltim.platforms.joritz.core.starter.search.SearchDto;

import java.util.*;

import org.springframework.data.jpa.domain.Specification;
/**
 * Class handling the data option search criteria for ALL and ANY
 * @author Gurudatta H
 */
public class SampleSpecificationBuilder {

    private final List<SearchCriteria> params;

    /**
	 * Constructs a new SampleSpecificationBuilder.
	 */
    public SampleSpecificationBuilder()
    {
        this.params = new ArrayList<>();
    }

    /**
     * @param key
     * @param operation
     * @param value
     * @return
     */
    public final SampleSpecificationBuilder with(String key, String operation, Object value)
    {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }

    /**
     * @param searchCriteria
     * @return 
     */
    public final SampleSpecificationBuilder with(SearchCriteria searchCriteria)
    {
        params.add(searchCriteria);
        return this;
    }

    /**
     * method to filter Specification of SampleEntity based on ALL or ANY condition
     * @return result returns filtered Specification of SampleEntity based on ALL or ANY condition
     */
    public Specification<SampleEntity> build()
    {
        if(params.isEmpty())
        {
            return null;
        }

        Specification<SampleEntity> result = new SampleSpecification(params.get(0));
        for (int idx = 1; idx < params.size(); idx++)
        {
            SearchCriteria criteria = params.get(idx);
            result =  SearchOperation.getDataOption(criteria
                     .getDataOption()) == SearchOperation.ALL
                     ? Specification.where(result).and(new    
                    		 SampleSpecification(criteria))
                     : Specification.where(result).or(
                       new SampleSpecification(criteria));
        }
        return result;
    }
}