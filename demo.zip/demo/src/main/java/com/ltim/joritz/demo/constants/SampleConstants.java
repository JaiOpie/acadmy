/**Copyright (c) 2023 LTIM. All rights reserved*/


package com.ltim.joritz.demo.constants;

/**
* Sample Constants class contains the  constants.
*  
* @author Archana reddy
*/

public class SampleConstants {

	public static final int NAME_MIN_VALUE = 5;
	public static final int NAME_MAX_VALUE = 100;
	public static final int DESCRIPTION_MIN_VALUE = 5;
	public static final int DESCRIPTION_MAX_VALUE = 500;
	public static final int SAMPLE_TYPE_MIN_VALUE = 5;
	public static final int SAMPLE_TYPE_MAX_VALUE = 100;
	public final static String CREATED_BY="createdBy";
	public final static String CREATED_ON="createdOn";
	public final static String SAMPLE_NAME="sampleName";
	public final static String SAMPLE_DESCRIPTION="sampleDescription";
	public final static String MODIFIED_BY="modifiedBy";
	public final static String MODIFIED_ON="modifiedOn";
	public static final String DEFAULT_SORT = "sampleId:ASC";
	public static final String SORT_BY_VALUES = "sortByValues";
	
	
	public static final String NAME_NOT_EMPTY = "name should not be empty";
	public static final String NAME_SIZE_RANGE = "Size of name should be between 6 and 32";
	public static final String NAME_ALLOWED_CHARACTERS = "Name should only contain alphanumeric characters";
	public static final String NO_MANAGE_PERMISSION = "User has no permissions";
	public static final String INVALID_ENTITY_ID= "Invalid entity id.";
	public static final String SAMPLE_ID="sampleId";
	
	
	
	public static final String EMAIL_FORMAT = "^[A-Za-z0-9+_.-]+@(.+)$";
	public static final String NAME_REGEX_PATTERN = "^[a-zA-Z0-9]+$";
	public static final String NAME_COLNAME = "name";
	
	
}
