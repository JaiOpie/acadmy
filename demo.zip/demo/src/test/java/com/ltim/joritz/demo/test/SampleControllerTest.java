//package com.ltim.joritz.demo.test;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.when;
//
//import java.util.Date;
//
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.ResponseEntity;
//
//import org.json.JSONException;
//import org.springframework.web.bind.MethodArgumentNotValidException;
//import com.ltim.platforms.joritz.core.starter.constants.JoritzCoreConstants;
//import java.util.ArrayList;
//import java.util.List;
//import org.springframework.data.domain.Sort;
//
//import com.ltim.platforms.joritz.core.starter.util.ApiResponse;
//import com.ltim.platforms.joritz.auth.starter.util.PermissionUtil;
//import com.ltim.platforms.joritz.core.starter.util.ResponseSettingUtil;
//
//import com.ltim.joritz.demo.controller.SampleController;
//import com.ltim.joritz.demo.entity.SampleEntity;
//import com.ltim.joritz.demo.service.SampleService;
//import com.ltim.joritz.demo.constants.PermissionScope;
//
//@SpringBootTest
//public class SampleControllerTest {
//	
//	@Autowired
//    private SampleController sampleController;
//	
//	@MockBean
//    private SampleService sampleService;
//	@MockBean
//    private PermissionUtil permissionUtil;
//	@MockBean
//    private ResponseSettingUtil responseSettingUtil;
//	
//	
//	@Test
//    void testAddSampleEntity() throws  MethodArgumentNotValidException {
//
//        // Mock data
//        long tenantId = 1L;
//        long groupId = 2L;
//        String userId = "user1";
//        
//        SampleEntity sampleEntity = new SampleEntity();
//        sampleEntity.setSampleId(1);
//        sampleEntity.setSampleName("SampleName");
//        sampleEntity.setSampleDescription("SampleDescription");
//
//        // Mock permission check
//        when(permissionUtil.hasClientScope(tenantId,PermissionScope.MANAGE_ACCESS,userId)).thenReturn(true);
//
//
//        // Mock service method
//        when(sampleService.addSampleEntity(any(SampleEntity.class))).thenReturn(sampleEntity);
//
//        // Test the controller method
//        ResponseEntity<ApiResponse> response = sampleController.addSample(tenantId, groupId, sampleEntity);
//        
//        ApiResponse apiResponse=response.getBody();
//
//        // Assertions
//        assertEquals(sampleEntity.getSampleName(), ((SampleEntity)apiResponse.getData()).getSampleName());
//        assertEquals(sampleEntity.getSampleDescription(), ((SampleEntity)apiResponse.getData()).getSampleDescription());
//        assertEquals(JoritzCoreConstants.API_ADD_ENTITY_SUCCESS_MESSAGE, apiResponse.getMessage());
//        assertEquals(true, apiResponse.isSuccess());
//        
//
//    }
//	
//	@Test
//    void testUpdateSampleEntity() throws JSONException, MethodArgumentNotValidException {
//
//		// Mock data
//        long tenantId = 1L;
//        long groupId = 2L;
//        long entityId = 1L;
//        
//        String userId = "user1";
//        
//        SampleEntity sampleEntity = new SampleEntity();
//        sampleEntity.setSampleId(entityId);
//        sampleEntity.setSampleName("SampleName");
//        sampleEntity.setSampleDescription("SampleDescription");
//
//        // Mock permission check
//        when(permissionUtil.hasResourceScope(tenantId, String.valueOf(entityId), 
//        		PermissionScope.MANAGE_ACCESS,userId)).thenReturn(true);
//
//        //Mock service method
//        when(sampleService.getSampleEntityById(entityId)).thenReturn(sampleEntity);
//        
//        // Mock service method
//        when(sampleService.updateSampleEntity(any(SampleEntity.class))).thenReturn(sampleEntity);
//
//        // Test the controller method
//        ResponseEntity<ApiResponse> response = sampleController.updateSample(tenantId, groupId, entityId ,sampleEntity);
//
//        ApiResponse apiResponse=response.getBody();
//
//        // Assertions
//        assertEquals(sampleEntity.getSampleName(), ((SampleEntity)apiResponse.getData()).getSampleName());
//        assertEquals(sampleEntity.getSampleDescription(), ((SampleEntity)apiResponse.getData()).getSampleDescription());
//        assertEquals(JoritzCoreConstants.API_UPDATE_ENTITY_SUCCESS_MESSAGE, apiResponse.getMessage());
//        assertEquals(true, apiResponse.isSuccess());
//        
//
//    }
//	
//	@Test
//    void testGetSampleEntity() throws  MethodArgumentNotValidException {
//
//        // Mock data
//		long tenantId = 1L;
//        long groupId = 2L;
//        String userId = "user1";
//        Sort sort = Sort.by("sampleId").ascending();
//        int page=1;
//        int size=5;
//
//        // Mock permission check
//        when(permissionUtil.hasClientScope(tenantId,PermissionScope.VIEW,userId)).thenReturn(true);
//        
//        List<SampleEntity> sampleEntityList  = new ArrayList<SampleEntity>(); 
//        
//        for(int i = 0; i < 5; i++){
//        	SampleEntity sampleEntity = new SampleEntity();
//        	sampleEntity.setSampleId(i);
//            sampleEntity.setSampleName("SampleName"+i);
//            sampleEntity.setSampleDescription("SampleDescription"+i);
//            
//            sampleEntityList.add(sampleEntity);
//        }
//        
//        // Mock service method
//        when(sampleService.getAllSampleEntities(page,size,sort)).thenReturn(sampleEntityList);
//
//        // Test the controller method
//        ResponseEntity<ApiResponse> response = sampleController.getAllSamples(tenantId, groupId, page , size , "sampleId:ASC");
//
//        ApiResponse apiResponse=response.getBody();
//
//        // Assertions
//        assertEquals(sampleEntityList.size(), ((List<SampleEntity>)apiResponse.getData()).size());
//        assertEquals(JoritzCoreConstants.API_FETCH_SUCCESS_MESSAGE,apiResponse.getMessage());
//        assertEquals(true, apiResponse.isSuccess());
//
//    }
//	
//	@Test
//    void testGetSample() throws  MethodArgumentNotValidException {
//
//		// Mock data
//        long tenantId = 1L;
//        long groupId = 2L;
//        long entityId = 1L;
//        String userId = "user1";
//        
//        SampleEntity sampleEntity = new SampleEntity();
//        sampleEntity.setSampleId(1);
//        sampleEntity.setSampleName("SampleName");
//        sampleEntity.setSampleDescription("SampleDescription");
//
//        // Mock permission check
//        when(permissionUtil.hasClientScope(tenantId,PermissionScope.VIEW,userId)).thenReturn(true);
//
//
//        // Mock service method
//        when(sampleService.getSampleEntityById((int)entityId)).thenReturn(sampleEntity);
//
//        // Test the controller method
//        ResponseEntity<ApiResponse> response = sampleController.getSample(tenantId, groupId, (int)entityId);
//
//        ApiResponse apiResponse=response.getBody();
//
//        // Assertions
//        assertEquals(sampleEntity.getSampleName(), ((SampleEntity)apiResponse.getData()).getSampleName());
//        assertEquals(sampleEntity.getSampleDescription(), ((SampleEntity)apiResponse.getData()).getSampleDescription());
//        assertEquals(JoritzCoreConstants.API_FETCH_SUCCESS_MESSAGE, apiResponse.getMessage());
//        assertEquals(true, apiResponse.isSuccess());
//
//    }
//	
//
//}
//
