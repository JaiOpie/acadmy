//package com.ltim.joritz.demo.test;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.data.domain.Sort;
//
//import com.ltim.joritz.demo.entity.SampleEntity;
//import com.ltim.joritz.demo.repository.SampleRepository;
//import com.ltim.joritz.demo.service.SampleService;
//
//
//@SpringBootTest
//public class SampleServiceTest {
//	
//	@InjectMocks
//    private SampleService sampleService;
//
//    @Mock
//    private SampleRepository sampleRepository;
//    
//    
//    @Test
//    public void testAddSampleEntity() {
//
//        // Create a sample entity
//        SampleEntity sampleEntity = new SampleEntity();
//        sampleEntity.setSampleId(1);
//        sampleEntity.setSampleName("SampleName");
//        sampleEntity.setSampleDescription("Sample Description");
//
//        // Mock the repository call
//        Mockito.when(sampleRepository.save(sampleEntity)).thenReturn(sampleEntity);
//
//        // Call the service method
//        SampleEntity savedEntity = sampleService.addSampleEntity(sampleEntity);
//
//        // Verify that the entity was saved
//        assertNotNull(savedEntity);
//        assertEquals(1, savedEntity.getSampleId());
//        assertEquals("SampleName", savedEntity.getSampleName());
//        assertEquals("Sample Description", savedEntity.getSampleDescription());
//    }
//    
//    @Test
//    public void testUpdateSampleEntity() {
//
//        // Create a sample entity with existing sample ID
//        SampleEntity sampleEntity = new SampleEntity();
//        sampleEntity.setSampleId(1);
//        sampleEntity.setSampleName("SampleName");
//        sampleEntity.setSampleDescription("Sample Description");
//
//        // Mock the repository call
//        Mockito.when(sampleRepository.save(sampleEntity)).thenReturn(sampleEntity);
//
//        // Call the service method
//        SampleEntity updatedEntity = sampleService.updateSampleEntity(sampleEntity);
//
//        // Verify that the entity was updated
//        assertNotNull(updatedEntity);
//        assertEquals(1, updatedEntity.getSampleId());
//        assertEquals("SampleName", updatedEntity.getSampleName());
//        assertEquals("Sample Description", updatedEntity.getSampleDescription());
//
//    }
//    
//    
//    @Test
//    public void testGetAllSampleEntities() {
//
//        // Mock the repository call to return a list of sample entities
//        List<SampleEntity> sampleEntities = new ArrayList<SampleEntity>();
//        sampleEntities.add(new SampleEntity(1, "Sample1", "Description 1"));
//        sampleEntities.add(new SampleEntity(2, "Sample2", "Description 2"));
//
//
//        Mockito.when(sampleRepository.findAll()).thenReturn(sampleEntities);
//
//        // Call the service method
//        List<SampleEntity> result = sampleService.getAllSampleEntities(1, 10, Sort.by(Sort.Order.asc("sampleId")));
//
//        // Verify that the result is not empty and contains the expected entities
//        assertNotNull(result);
//        assertEquals(2, result.size());
//        assertEquals(1, result.get(0).getSampleId());
//        assertEquals("Sample1", result.get(0).getSampleName());
//        assertEquals("Description 1", result.get(0).getSampleDescription());
//        assertEquals(2, result.get(1).getSampleId());
//        assertEquals("Sample2", result.get(1).getSampleName());
//        assertEquals("Description 2", result.get(1).getSampleDescription());
//    }
//    
//    
//    @Test
//    public void testGetSampleEntity() {
//
//        // Mock the repository call to return a sample entity by ID
//    	long sampleId = 1;
//        SampleEntity sampleEntity = new SampleEntity(sampleId, "SampleName", "Sample Description");
//
//        Mockito.when(sampleRepository.findById(sampleId)).thenReturn(Optional.of(sampleEntity));
//
//        // Call the service method
//        SampleEntity result = sampleService.getSampleEntityById(sampleId);
//
//        // Verify that the result is not null and contains the expected entity
//        assertNotNull(result);
//        assertEquals(sampleId, result.getSampleId());
//        assertEquals("SampleName", result.getSampleName());
//        assertEquals("Sample Description", result.getSampleDescription());
//    }
//
//}
//
